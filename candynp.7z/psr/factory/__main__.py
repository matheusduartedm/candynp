import sys
from .get_version import VERSION

if __name__ == "__main__":
    if len(sys.argv) > 1:
        first_arg = sys.argv[1].lower().strip()
        if first_arg == "--version" or first_arg == "-v":
            print(VERSION)
            sys.exit(0)
    sys.exit(1)
