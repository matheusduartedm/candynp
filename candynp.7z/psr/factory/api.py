import locale
import sys
from typing import Union, List, Tuple
import ctypes
import os
from . import factorylib

# Check whether pandas' dataframe is available.
_HAS_PANDAS = False
try:
    import pandas as pd
    import pandas.api.interchange

    _HAS_PANDAS = True
except ImportError:
    pd = None
    _HAS_PANDAS = False

# States whether the library is initialized.
# It should be to correctly load and build models.
_initialized = False

# System encoding for interface with the library.
_preferred_encoding = locale.getpreferredencoding()


def _check_initialized():
    """Checks if the module was initialized."""
    global _initialized
    if not _initialized:
        _initialize()
        _initialized = True


def _c_str(value: str) -> bytes:
    """Convert a Python object/string into a bytes/c-array."""
    return bytes(value, encoding=_preferred_encoding)


def _from_c_str(value: bytes) -> str:
    """Convert ASCII bytes back into utf-8 strings."""
    return value.decode(encoding=_preferred_encoding)


def _nbytes(value: str) -> int:
    """Return the bytes' count of the equivalent C buffer to
    hold this string."""
    return len(value) + 1


class FactoryException(Exception):
    pass


def _version_long() -> str:
    _check_initialized()
    size = 200
    buffer = ctypes.create_string_buffer(size)
    status = factorylib.lib.psrd_version_long(buffer, size)
    if status == 0:
        return _from_c_str(buffer.value)
    return ""


def _version_short() -> str:
    _check_initialized()
    size = 200
    buffer = ctypes.create_string_buffer(size)
    status = factorylib.lib.psrd_version_short(buffer, size)
    if status == 0:
        return _from_c_str(buffer.value)
    return ""


def version() -> str:
    """Returns module version."""
    return "factory {}, {}".format(get_version.VERSION, _version_long())


def build_version() -> str:
    """Returns short library version."""
    return _version_short()


def _get_context(models_or_context: Union[str, list, "Context", None],
                 blocks: Union[int, None] = None):
    if isinstance(models_or_context, Context):
        context = models_or_context
    elif isinstance(models_or_context, (str, list)) or models_or_context is None:
        context = Context.create()
        if isinstance(models_or_context, list):
            context.set("Models", models_or_context)
        elif isinstance(models_or_context, str):
            context.set("Models", [models_or_context, ])
    else:
        raise TypeError("Unexpected type for profile_or_context argument.")
    if blocks is not None and isinstance(blocks, int):
        context.set("Blocks", blocks)
    return context


class _BaseObject:
    def __init__(self):
        self._hdr = None

    def handler(self):
        return self._hdr

    def __hash__(self):
        return self._hdr


class Error(_BaseObject):
    def __init__(self):
        super().__init__()
        self._hdr = factorylib.lib.psrd_new_error()

    @property
    def code(self) -> int:
        return factorylib.lib.psrd_error_code(self._hdr)

    @code.setter
    def code(self, value):
        raise AttributeError("do not set code")

    @code.deleter
    def code(self):
        raise AttributeError("do not delete code")

    @property
    def what(self) -> str:
        size = 400
        buffer = ctypes.create_string_buffer(size)
        status = factorylib.lib.psrd_error_message(self._hdr,
                                                   buffer, size)
        if status == 0:
            return _from_c_str(buffer.value)
        return ""

    @what.deleter
    def what(self):
        raise AttributeError("do not delete what")

    @what.setter
    def what(self, value):
        raise AttributeError("do not set what")

    def __del__(self):
        if self._hdr is not None:
            factorylib.lib.psrd_free_error(self._hdr)

    def __repr__(self):
        return f"Error object with code \"{self.code}\" and message:\n" \
               f"{self.what}"

    def __str__(self):
        return self.what


class _TableColumn:
    def __init__(self):
        self.name = ""
        self.values = []

    def __len__(self):
        return len(self.values)


class _Table(_BaseObject):
    def __init__(self):
        super().__init__()
        self._hdr = factorylib.lib.psrd_new_table()
        self.index: Union[_TableColumn, None] = None
        self.columns: List[Union[_TableColumn, None]] = []

    def __del__(self):
        if self._hdr is not None:
            factorylib.lib.psrd_free_table(self._hdr)


class ValueList(_BaseObject):
    def __init__(self, initialized=True):
        super().__init__()
        self._hdr = factorylib.lib.psrd_new_list() if initialized else None

    def __del__(self):
        if self._hdr is not None:
            factorylib.lib.psrd_free_list(self._hdr)

    @staticmethod
    def from_list(value: Union[List, Tuple]):
        err = Error()
        list_obj = ValueList()
        for obj in value:
            val_obj = Value()
            val_obj.set(obj)
            status = factorylib.lib.psrd_list_append(list_obj.handler(),
                                                     val_obj.handler(),
                                                     err.handler())
            if status != 0:
                FactoryException(err.what)
        return list_obj

    def to_list(self) -> list:
        err = Error()
        count_value = ctypes.c_long()
        status = factorylib.lib.psrd_list_count(self._hdr,
                                                ctypes.byref(count_value),
                                                err.handler())
        if status != 0:
            raise FactoryException(err.what)
        values_count = int(count_value.value)

        list_of_values = []
        value = Value()
        for i_value in range(values_count):
            status = factorylib.lib.psrd_list_get(self._hdr, i_value,
                                                  value.handler(), err.handler())
            if status != 0:
                raise FactoryException(err.what)
            list_of_values.append(value.get())
        return list_of_values


class Value(_BaseObject):
    def __init__(self):
        super().__init__()
        self._hdr = factorylib.lib.psrd_new_value()

    def __del__(self):
        if self._hdr is not None:
            factorylib.lib.psrd_free_value(self._hdr)

    def get(self) -> Union[int, float, str, "DataObject", ValueList, None]:
        _err = Error()
        uintval = ctypes.c_long()
        status = factorylib.lib.psrd_value_get_type(self._hdr,
                                                    ctypes.byref(uintval),
                                                    _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        vartype = int(uintval.value)
        # TODO: update the types accordingly.
        if vartype in (0, 2):
            # as int
            intval = ctypes.c_int()
            status = factorylib.lib.psrd_value_get_int(self._hdr,
                                                       ctypes.byref(intval),
                                                       _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
            return int(intval.value)
        elif vartype == 1:
            # as float
            flval = ctypes.c_double()
            status = factorylib.lib.psrd_value_get_real(self._hdr,
                                                        ctypes.byref(flval),
                                                        _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
            return float(flval.value)
        elif vartype in (3, 4):
            # as string
            size = factorylib.lib.psrd_value_get_string(self._hdr, None, 0,
                                                        _err.handler())
            buffer = ctypes.create_string_buffer(size)
            status = factorylib.lib.psrd_value_get_string(self._hdr, buffer, size,
                                                          _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
            return _from_c_str(buffer.value)
        elif vartype == 7:
            # Null type
            return None
        elif vartype == 5:
            # Object type
            obj = DataObject()
            ref = factorylib.lib.psrd_value_get_object(self._hdr,
                                                       _err.handler())
            if _err.code != 0 or ref is None:
                raise FactoryException(_err.what)
            obj._hdr = ref
            return obj
        elif vartype == 6:
            # List type
            list_obj = ValueList()
            ref = factorylib.lib.psrd_value_get_list(self._hdr,
                                                     _err.handler())
            if _err.code != 0 or ref is None:
                raise FactoryException(_err.what)
            list_obj._hdr = ref
            return list_obj.to_list()
        else:
            raise NotImplementedError()

    def set(self, value):
        _err = Error()
        if isinstance(value, float):
            status = factorylib.lib.psrd_value_set_real(self._hdr, value,
                                                        _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
        elif isinstance(value, int) or isinstance(value, bool):
            status = factorylib.lib.psrd_value_set_int(self._hdr, value,
                                                       _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
        elif isinstance(value, str):
            status = factorylib.lib.psrd_value_set_string(self._hdr,
                                                          _c_str(value),
                                                          _nbytes(value),
                                                          _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
        elif isinstance(value, DataObject):
            status = factorylib.lib.psrd_value_set_object(self._hdr,
                                                          value.handler(),
                                                          _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
        elif isinstance(value, (list, tuple, ValueList)):
            if isinstance(value, (list, tuple)):
                list_obj = ValueList.from_list(value)
            else:
                list_obj = value
            status = factorylib.lib.psrd_value_set_list(self._hdr,
                                                        list_obj.handler(),
                                                        _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
        elif value is None:
            status = factorylib.lib.psrd_value_set_null(self._hdr,
                                                        _err.handler())
            if status != 0:
                raise FactoryException(_err.what)


class PropertyDescription(_BaseObject):
    def __init__(self):
        super().__init__()
        self._hdr = None

    def __del__(self):
        if self._hdr is not None:
            factorylib.lib.psrd_free_property_description(self._hdr)

    @property
    def name(self) -> str:
        _err = Error()
        size = 100
        buffer = ctypes.create_string_buffer(size)
        status = factorylib.lib.psrd_property_description_get_name(self._hdr, buffer, size,
                                                                   _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        return _from_c_str(buffer.value)

    @name.setter
    def name(self, value):
        raise AttributeError("do not set name")

    @name.deleter
    def name(self):
        raise AttributeError("do not delete code")

    def is_dynamic(self) -> bool:
        _err = Error()
        value = ctypes.c_bool()
        status = factorylib.lib.psrd_property_description_is_dynamic(self._hdr,
                                                                     ctypes.byref(value),
                                                                     _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        return bool(value.value)

    def is_indexed(self) -> bool:
        _err = Error()
        value = ctypes.c_bool()
        status = factorylib.lib.psrd_property_description_is_indexed(self._hdr,
                                                                     ctypes.byref(value),
                                                                     _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        return bool(value.value)

    def is_grouped(self) -> bool:
        _err = Error()
        value = ctypes.c_bool()
        status = factorylib.lib.psrd_property_description_is_grouped(self._hdr,
                                                                     ctypes.byref(value),
                                                                     _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        return bool(value.value)

    def dimensions(self) -> List[Tuple[str, int]]:
        _err = Error()
        dimensions = []
        value = ctypes.c_long()
        status = factorylib.lib.psrd_property_description_dimensions_count(self._hdr,
                                                                           ctypes.byref(value),
                                                                           _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        dimensions_count = int(value.value)

        for i_dim in range(dimensions_count):
            size = 100
            buffer = ctypes.create_string_buffer(size)
            status = factorylib.lib.psrd_property_description_get_dimension_name(self._hdr,
                                                                                 i_dim, buffer,
                                                                                 size,
                                                                                 _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
            name = _from_c_str(buffer.value)

            status = factorylib.lib.psrd_property_description_get_dimension_size(self._hdr,
                                                                                 i_dim,
                                                                                 ctypes.byref(value),
                                                                                 _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
            size = int(value.value)

            dimensions.append((name, size))
        return dimensions

    def __repr__(self):
        return self.__str__()

    def __str__(self):
        dimensions = self.dimensions()
        if len(dimensions) == 0:
            return f"Property {self.name}"
        else:
            return f"Property {self.name} with dimensions {self.dimensions()}"


def _build_table_after_fetch(table: _Table):
    _err = Error()
    name_buffer_length = 200
    _columns_count = ctypes.c_long()
    status = factorylib.lib.psrd_table_columns_count(table.handler(),
                                                     ctypes.byref(_columns_count),
                                                     _err.handler())
    if status != 0:
        raise FactoryException(_err.what)
    columns_count = _columns_count.value

    _rows_count = ctypes.c_long()
    status = factorylib.lib.psrd_table_rows_count(table.handler(),
                                                  ctypes.byref(_rows_count),
                                                  _err.handler())
    if status != 0:
        raise FactoryException(_err.what)
    rows_count = _rows_count.value

    _is_indexed = ctypes.c_bool()
    status = factorylib.lib.psrd_table_is_indexed(table.handler(),
                                                  ctypes.byref(_is_indexed),
                                                  _err.handler())
    if status != 0:
        raise FactoryException(_err.what)
    is_indexed = _is_indexed.value
    value = Value()

    buffer = ctypes.create_string_buffer(name_buffer_length)
    if is_indexed:
        table.index = _TableColumn()
        table.index.name = ""
        status = factorylib.lib.psrd_table_index_get_name(table.handler(), buffer,
                                                          name_buffer_length,
                                                          _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        table.index.name = _from_c_str(buffer.value)
        table.index.values = [None] * rows_count
        for irow in range(0, rows_count):
            status = factorylib.lib.psrd_table_index_get_value(table.handler(),
                                                               irow, value.handler(),
                                                               _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
            table.index.values[irow] = value.get()

    table.columns = [_TableColumn() for _ in range(columns_count)]
    for column in range(columns_count):
        status = factorylib.lib.psrd_table_column_get_name(table.handler(), column,
                                                           buffer, name_buffer_length,
                                                           _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        table.columns[column].name = _from_c_str(buffer.value)

        table.columns[column].values = [None] * rows_count
        for row in range(rows_count):
            status = factorylib.lib.psrd_table_column_get_value(table.handler(),
                                                                column, row,
                                                                value.handler(),
                                                                _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
            table.columns[column].values[row] = value.get()


def _build_dataframe_from_table(table: _Table) -> "pd.DataFrame":
    if not _HAS_PANDAS:
        raise ModuleNotFoundError("pandas required.")
    data = {column.name: column.values
            for column in table.columns}
    index = table.index.values if table.index is not None else None
    return pd.DataFrame(data=data, index=index, dtype=object)


def _build_table_from_dataframe(table_data: "pd.DataFrame") -> _Table:
    _err = Error()
    table = _Table()
    value = Value()
    columns = len(table_data.columns)
    rows = len(table_data.values)

    status = factorylib.lib.psrd_table_resize(table.handler(), columns, rows,
                                              _err.handler())
    if status != 0:
        raise FactoryException(_err.what)

    for icolumn, column_name in enumerate(table_data.columns):
        status = factorylib.lib.psrd_table_column_set_name(table.handler(),
                                                           icolumn,
                                                           _c_str(column_name),
                                                           _nbytes(column_name),
                                                           _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

        column_array = table_data[column_name].values
        for irow in range(rows):
            value.set(column_array[irow])
            status = factorylib.lib.psrd_table_column_set_value(table.handler(),
                                                                icolumn,
                                                                irow,
                                                                value.handler(),
                                                                _err.handler())
            if status != 0:
                raise FactoryException(_err.what)

    if table_data.index is not None and len(table_data.index) > 0:
        index_name = "Date"
        status = factorylib.lib.psrd_table_index_set_name(table.handler(),
                                                          _c_str(index_name),
                                                          _nbytes(index_name),
                                                          _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

        for irow in range(rows):
            value.set(table_data.index[irow])
            status = factorylib.lib.psrd_table_index_set_value(table.handler(),
                                                               irow,
                                                               value.handler(),
                                                               _err.handler())
            if status != 0:
                raise FactoryException(_err.what)
    return table


class DataObject(_BaseObject):
    def __init__(self):
        super().__init__()
        self._hdr = None

    def __del__(self):
        if self._hdr is not None:
            factorylib.lib.psrd_free_object(self._hdr)

    def __eq__(self, other):
        err = Error()
        value = ctypes.c_bool()
        if self._hdr == other.handler():
            return True
        status = factorylib.lib.psrd_object_is_equals_to(self._hdr,
                                                         other.handler(),
                                                         ctypes.byref(value),
                                                         err.handler())
        if status != 0:
            raise FactoryException(err.what)
        return bool(value.value)

    def __hash__(self):
        return factorylib.lib.psrd_object_get_handler(self._hdr)

    def __copy__(self):
        dest = DataObject()
        _err = Error()
        ref = factorylib.lib.psrd_object_clone(self.handler(),
                                               _err.handler())
        if _err.code != 0 or ref is None:
            raise FactoryException(_err.what)
        dest._hdr = ref
        return dest

    def __deepcopy__(self, memodict=None):
        raise NotImplementedError()

    def __repr__(self):
        identifiers = []
        if self.code != 0:
            identifiers.append(f"code={self.code}")
        if self.id != "":
            identifiers.append(f"id={self.id.strip()}")
        if self.name != "":
            identifiers.append(f"name={self.name.strip()}")
        return f"psr.factory.DataObject({self.type}, {', '.join(identifiers)})"

    def help(self) -> str:
        return help(self.type)

    @property
    def context(self) -> "Context":
        _check_initialized()
        obj = Context()
        _err = Error()
        ref = factorylib.lib.psrd_object_context(self._hdr,
                                                 _err.handler())
        if _err.code != 0 or ref is None:
            raise FactoryException(_err.what)
        obj._hdr = ref
        return obj

    def properties(self) -> List[PropertyDescription]:
        _err = Error()
        value = ctypes.c_long()
        status = factorylib.lib.psrd_object_property_description_count(self._hdr,
                                                                       ctypes.byref(value),
                                                                       _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        var_count = int(value.value)
        properties = []
        for i_var in range(var_count):
            var = PropertyDescription()
            ref = factorylib.lib.psrd_object_get_property_description(self._hdr,
                                                                      i_var,
                                                                      _err.handler())
            if _err.code != 0 or ref is None:
                raise FactoryException(_err.what)
            var._hdr = ref
            properties.append(var)
        return properties

    def get(self, expression: str) -> Union[int, float, str, "DataObject", ValueList, None]:
        value = Value()
        _err = Error()
        status = factorylib.lib.psrd_object_get_value(self._hdr,
                                                      _c_str(expression),
                                                      value.handler(),
                                                      _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        return value.get()

    def get_at(self, expression: str, value_range: str) -> Union[int, float, str, "DataObject", ValueList, None]:
        value = Value()
        _err = Error()
        status = factorylib.lib.psrd_object_get_value_at(self._hdr,
                                                         _c_str(expression),
                                                         _c_str(value_range),
                                                         value.handler(),
                                                         _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        return value.get()

    def fetch(self, expression: str) -> "pandas.DataFrame":
        _err = Error()
        table = _Table()
        status = factorylib.lib.psrd_object_fetch(self._hdr, table.handler(),
                                                  _c_str(expression),
                                                  _nbytes(expression),
                                                  _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        _build_table_after_fetch(table)
        return _build_dataframe_from_table(table)

    def set(self, expression: str, value):
        _err = Error()
        _val = Value()
        _val.set(value)
        status = factorylib.lib.psrd_object_set_value(self._hdr, _c_str(expression),
                                                      _nbytes(expression),
                                                      _val.handler(),
                                                      _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

    def set_at(self, expression: str, range_expr: str, value):
        _err = Error()
        _val = Value()
        _val.set(value)
        status = factorylib.lib.psrd_object_set_value_at(self._hdr,
                                                         _c_str(expression),
                                                         _nbytes(expression),
                                                         _c_str(range_expr),
                                                         _nbytes(range_expr),
                                                         _val.handler(),
                                                         _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

    def update(self, dataframe_like):
        if not _HAS_PANDAS:
            raise ModuleNotFoundError("pandas required.")
        dataframe_like = pandas.api.interchange.from_dataframe(dataframe_like)
        _err = Error()
        _table = _build_table_from_dataframe(dataframe_like)
        status = factorylib.lib.psrd_object_update(self._hdr, _table.handler(),
                                                   _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

    def parent(self) -> Union["Study", None]:
        study_ptr = Study()
        _err = Error()
        ref = factorylib.lib.psrd_object_get_parent(self._hdr,
                                                    _err.handler())
        if _err.code != 0:
            raise FactoryException(_err.what)
        if ref is None:
            return None
        study_ptr._hdr = ref
        return study_ptr

    def referenced_by(self) -> List["DataObject"]:
        object_list = ValueList(False)
        _err = Error()
        ref = factorylib.lib.psrd_object_referenced_by(self._hdr,
                                                       _err.handler())
        if _err.code != 0 or ref is None:
            raise FactoryException(_err.what)
        object_list._hdr = ref
        return object_list.to_list()

    @property
    def code(self) -> int:
        _err = Error()
        value = ctypes.c_int()
        status = factorylib.lib.psrd_object_get_code(self._hdr,
                                                     ctypes.byref(value),
                                                     _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        return value.value

    @code.setter
    def code(self, value: int):
        _err = Error()
        status = factorylib.lib.psrd_object_set_code(self._hdr, value,
                                                     _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

    @code.deleter
    def code(self):
        raise AttributeError("do not delete code")

    @property
    def type(self) -> str:
        _err = Error()
        size = 100
        buffer = ctypes.create_string_buffer(size)
        status = factorylib.lib.psrd_object_get_type(self._hdr, buffer,
                                                     size, _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        return _from_c_str(buffer.value)

    @type.setter
    def type(self, value: str):
        raise AttributeError("do not set type")

    @type.deleter
    def type(self):
        raise AttributeError("do not delete type")

    @property
    def name(self) -> str:
        _err = Error()
        size = 100
        buffer = ctypes.create_string_buffer(size)
        status = factorylib.lib.psrd_object_get_name(self._hdr, buffer,
                                                     size, _err.handler())
        if status == 0:
            return _from_c_str(buffer.value)
        raise FactoryException(_err.what)

    @name.setter
    def name(self, value: str):
        _err = Error()
        status = factorylib.lib.psrd_object_set_name(self._hdr,
                                                     _c_str(value),
                                                     _nbytes(value),
                                                     _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

    @name.deleter
    def name(self):
        raise AttributeError("do not delete name")

    @property
    def id(self) -> str:
        _err = Error()
        size = 100
        buffer = ctypes.create_string_buffer(size)
        status = factorylib.lib.psrd_object_get_id(self._hdr, buffer,
                                                   size, _err.handler())
        if status == 0:
            return _from_c_str(buffer.value)
        raise FactoryException(_err.what)

    @id.setter
    def id(self, value: str):
        _err = Error()
        status = factorylib.lib.psrd_object_set_id(self._hdr,
                                                   _c_str(value),
                                                   _nbytes(value),
                                                   _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

    @id.deleter
    def id(self):
        raise AttributeError("do not delete id")


class Context(DataObject):
    @staticmethod
    def default_context() -> "Context":
        _check_initialized()
        context = Context()
        err = Error()
        ref = factorylib.lib.psrd_get_default_context(err.handler())
        if err.code != 0 or ref is None:
            raise FactoryException(err.what)
        context._hdr = ref
        return context

    @staticmethod
    def create() -> "Context":
        context_obj = create("Context", None)
        context = Context()
        context._hdr = context_obj._hdr
        context_obj._hdr = None
        return context


class Study(_BaseObject):
    def __init__(self):
        super().__init__()
        self.find_by_name = self.find

    def __del__(self):
        if self._hdr is not None:
            factorylib.lib.psrd_free_study(self._hdr)

    def __hash__(self):
        return factorylib.lib.psrd_study_get_handler(self._hdr)

    def __eq__(self, other: "Study"):
        err = Error()
        value = ctypes.c_bool()
        if self._hdr == other.handler():
            return True
        status = factorylib.lib.psrd_study_is_equals_to(self._hdr,
                                                        other.handler(),
                                                        ctypes.byref(value),
                                                        err.handler())
        if status != 0:
            raise FactoryException(err.what)
        return bool(value.value)

    def __copy__(self):
        raise NotImplementedError()

    def __deepcopy__(self, memodict=None):
        dest = Study()
        _err = Error()
        ref = factorylib.lib.psrd_study_clone(self.handler(),
                                              _err.handler())
        if _err.code != 0 or ref is None:
            raise FactoryException(_err.what)
        dest._hdr = ref
        return dest

    @staticmethod
    def help():
        return help("Study")

    @staticmethod
    def create(profile_or_context: Union[str, Context, None],
               blocks: Union[int, None] = None):
        _check_initialized()
        err = Error()
        context = _get_context(profile_or_context, blocks)
        study = Study()
        study._hdr = factorylib.lib.psrd_study_create(context.handler(),
                                                      err.handler())
        if err.code != 0:
            raise FactoryException(err.what)
        return study

    @staticmethod
    def load(study_path: str, profile_or_context: Union[str, Context, None],
             options: Union[None, DataObject] = None):
        if not isinstance(options, (DataObject, type(None))):
            raise TypeError("options must be a DataObject or None.")
        context = _get_context(profile_or_context, None)
        err = Error()
        options_handler = options.handler() if options is not None else None
        study = Study()
        study._hdr = factorylib.lib.psrd_study_load(_c_str(study_path),
                                                    _nbytes(study_path),
                                                    options_handler,
                                                    context.handler(),
                                                    err.handler())
        if err.code != 0:
            raise FactoryException(err.what)
        return study

    def save(self, output_path: str, options: Union[None, DataObject] = None):
        if not isinstance(options, (DataObject, type(None))):
            raise TypeError("options must be a DataObject or None.")
        _err = Error()
        _options_handler = options.handler() if options is not None else None
        status = factorylib.lib.psrd_study_save(self._hdr, _c_str(output_path),
                                                _nbytes(output_path),
                                                _options_handler,
                                                _err.handler())
        if _err.code != 0:
            raise FactoryException(_err.what)

    @property
    def context(self) -> "Context":
        _check_initialized()
        obj = Context()
        _err = Error()
        ref = factorylib.lib.psrd_study_context(self._hdr,
                                                _err.handler())
        if _err.code != 0 or ref is None:
            raise FactoryException(_err.what)
        obj._hdr = ref
        return obj

    def get(self, expression: str) -> Union[int, float, str, "DataObject", ValueList, None]:
        value = Value()
        _err = Error()
        status = factorylib.lib.psrd_study_get_value(self._hdr,
                                                     _c_str(expression),
                                                     value.handler(),
                                                     _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        return value.get()

    def get_at(self, expression: str, value_range: str) -> Union[int, float, str, "DataObject", ValueList, None]:
        value = Value()
        _err = Error()
        status = factorylib.lib.psrd_study_get_value_at(self._hdr,
                                                        _c_str(expression),
                                                        _c_str(value_range),
                                                        value.handler(),
                                                        _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        return value.get()

    def add(self, obj: DataObject):
        if not isinstance(obj, DataObject):
            raise TypeError("obj must be a DataObject.")
        _err = Error()
        status = factorylib.lib.psrd_study_add(self._hdr,
                                               obj.handler(),
                                               _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

    def remove(self, obj: DataObject):
        if not isinstance(obj, DataObject):
            raise TypeError("obj must be a DataObject.")
        _err = Error()
        status = factorylib.lib.psrd_study_remove(self._hdr,
                                                  obj.handler(),
                                                  _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

    def find(self, expression: str) -> List[DataObject]:
        object_list = ValueList(False)
        _err = Error()
        ref = factorylib.lib.psrd_study_find(self._hdr,
                                             _c_str(expression),
                                             _err.handler())
        if _err.code != 0 or ref is None:
            raise FactoryException(_err.what)
        object_list._hdr = ref
        return object_list.to_list()

    def find_by_code(self, expression: str) -> List[DataObject]:
        object_list = ValueList(False)
        _err = Error()
        ref = factorylib.lib.psrd_study_find_by_code(self._hdr,
                                                     _c_str(expression),
                                                     _err.handler())
        if _err.code != 0 or ref is None:
            raise FactoryException(_err.what)
        object_list._hdr = ref
        return object_list.to_list()

    def find_by_id(self, expression: str) -> List[DataObject]:
        object_list = ValueList(False)
        _err = Error()
        ref = factorylib.lib.psrd_study_find_by_id(self._hdr,
                                                   _c_str(expression),
                                                   _err.handler())
        if _err.code != 0 or ref is None:
            raise FactoryException(_err.what)
        object_list._hdr = ref
        return object_list.to_list()

    def set(self, expression: str, value):
        _err = Error()
        _val = Value()
        _val.set(value)
        status = factorylib.lib.psrd_study_set_value(self._hdr,
                                                     _c_str(expression),
                                                     _nbytes(expression),
                                                     _val.handler(),
                                                     _err.handler())
        if status != 0:
            raise FactoryException(_err.what)

    def set_at(self, expression: str, range_expr: str, value):
        err = Error()
        val = Value()
        val.set(value)
        status = factorylib.lib.psrd_study_set_value_at(self._hdr,
                                                        _c_str(expression),
                                                        _nbytes(expression),
                                                        _c_str(range_expr),
                                                        _nbytes(range_expr),
                                                        val.handler(),
                                                        err.handler())
        if status != 0:
            raise FactoryException(err.what)

    def fetch(self, expression: str) -> "pandas.DataFrame":
        _err = Error()
        table = _Table()
        status = factorylib.lib.psrd_study_fetch(self._hdr, table.handler(),
                                                 _c_str(expression),
                                                 _nbytes(expression),
                                                 _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        _build_table_after_fetch(table)
        return _build_dataframe_from_table(table)

    def get_objects_values(self, object_type: str, columns: List[str]) -> "pandas.DataFrame":
        _err = Error()
        table = _Table()
        columns_list = Value()
        columns_list.set(columns)
        status = factorylib.lib.psrd_study_get_objects_values(self._hdr, table.handler(),
                                                              _c_str(object_type),
                                                              columns_list.handler(),
                                                              _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        _build_table_after_fetch(table)
        return _build_dataframe_from_table(table)

    def get_objects_values_at(self, object_type: str, columns: List[str], range_expr: str) -> "pandas.DataFrame":
        _err = Error()
        table = _Table()
        columns_list = Value()
        columns_list.set(columns)
        status = factorylib.lib.psrd_study_get_objects_values_at(self._hdr, table.handler(),
                                                                 _c_str(object_type),
                                                                 columns_list.handler(),
                                                                 _c_str(range_expr),
                                                                 _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        _build_table_after_fetch(table)
        return _build_dataframe_from_table(table)

    def properties(self) -> List[PropertyDescription]:
        _err = Error()
        value = ctypes.c_long()
        status = factorylib.lib.psrd_study_property_description_count(self._hdr,
                                                                      ctypes.byref(value),
                                                                      _err.handler())
        if status != 0:
            raise FactoryException(_err.what)
        var_count = int(value.value)
        properties = []
        for i_var in range(var_count):
            var = PropertyDescription()
            ref = factorylib.lib.psrd_study_get_property_description(self._hdr,
                                                                     i_var,
                                                                     _err.handler())
            if _err.code != 0 or ref is None:
                raise FactoryException(_err.what)
            properties.append(var)
        return properties

    def update(self, dataframe_like):
        if not _HAS_PANDAS:
            raise ModuleNotFoundError("pandas required.")
        dataframe_like = pandas.api.interchange.from_dataframe(dataframe_like)
        _err = Error()
        _table = _build_table_from_dataframe(dataframe_like)
        status = factorylib.lib.psrd_study_update(self._hdr, _table.handler(),
                                                  _err.handler())
        if status != 0:
            raise FactoryException(_err.what)


def _initialize():
    factorylib.initialize()
    _err = Error()
    # Where to look for pmd and pmk files
    common_path = os.path.dirname(__file__)
    status = factorylib.lib.psrd_initialize(_c_str(common_path),
                                            _nbytes(common_path),
                                            _err.handler())
    if status != 0:
        raise FactoryException(_err.what)


def _unload():
    _err = Error()
    status = factorylib.lib.psrd_unload(_err.handler())
    if status != 0:
        raise FactoryException(_err.what)


def help(context: str = "") -> str:
    _err = Error()
    size = 25000
    buffer = ctypes.create_string_buffer(size)
    status = factorylib.lib.psrd_help(_c_str(context), _nbytes(context),
                                      buffer, size, _err.handler())
    if status != 0:
        raise FactoryException(_err.what)
    return _from_c_str(buffer.value)


def create_study(*args, **kwargs) -> Study:
    blocks = kwargs.get("blocks", None)
    models = kwargs.get("models", None)
    context = kwargs.get("context", None) if len(args) == 0 else args[0]
    profile = kwargs.get("profile", None)
    if models is None and profile is not None and len(profile) > 0:
        models = [profile, ]
    profile_or_context = models if models is not None and len(models) > 0 \
        else context
    return Study.create(profile_or_context, blocks)


def load_study(study_path: str,
               profile_or_context: Union[str, Context, None] = None,
               options: Union[None, DataObject] = None) -> Study:
    return Study.load(study_path, profile_or_context, options)


def create(class_name: str,
           profile_or_context: Union[str, Context, None] = None) -> Union[DataObject, None]:
    _check_initialized()
    obj = DataObject()
    _err = Error()
    context = _get_context(profile_or_context, None) \
        if class_name != "Context" else None
    context_hdr = context.handler() if context is not None else None
    ref = factorylib.lib.psrd_create(_c_str(class_name),
                                     context_hdr,
                                     _err.handler())
    if _err.code != 0 or ref is None:
        raise FactoryException(_err.what)
    obj._hdr = ref
    return obj


def get_default_context() -> "Context":
    _check_initialized()
    return Context.default_context()


def get_new_context() -> "Context":
    _check_initialized()
    return Context.create()


def get_default_encoding() -> str:
    return _preferred_encoding


def set_default_encoding(encoding: str):
    global _preferred_encoding
    _preferred_encoding = encoding
